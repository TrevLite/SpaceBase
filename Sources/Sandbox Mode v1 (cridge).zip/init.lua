-- Sandbox Mode Mod v1
-- by Cridge (SteamID)
--
-- Mod loader based version so standard game files are not overwritten
-- Conversion by WrathOf/Squirrely Wrath (Forum/Steam ID)
--

local modname = "Sandbox Mode Mod (cridge)"
local modversion = "v1"

--Add mod name to app version so shows on title and menu screens
local str = MOAIEnvironment.appVersion
local i = string.find(str, '\n')
--add newline if not found
if not i then str = str..'\n' end
--add spacer if previous mod name exists (based on chars existing after newline)
if i and string.len(string.sub(str, i+1)) > 0 then str = str..' - ' end
--add this mod's name
str = str..modname..' '..modversion
MOAIEnvironment.appVersion = str


--Private variable to enble additional debugging messages in "moai_log_Space.txt"
--located in the game's installation folder with space.exe
local bDebugFlag = false



-------------------------------------------------------------------------------
-- GameRules.lua changes
-------------------------------------------------------------------------------
local GameRules = require('GameRules')

--Change variables to adjust settings as desired
--NOTE: Only 6 digits are shown in UI so perhaps 999999 would be less confusing?
GameRules.STARTING_MATTER = 2000000		--2000


-------------------------------------------------------------------------------
-- CharacterConstants.lua changes
-------------------------------------------------------------------------------
local CharacterConstants = require('CharacterConstants')

--
-- morale events
--

-- good things
CharacterConstants.MORALE_NICE_CHAT = 5			-- 0
--CharacterConstants.MORALE_MET_NEW_CITIZEN = 6
CharacterConstants.MORALE_MINE_ASTEROID = 5		-- 0
CharacterConstants.MORALE_MAINTAIN_OBJECT = 5	-- 0
CharacterConstants.MORALE_MAINTAIN_PLANT = 5	-- 0
CharacterConstants.MORALE_REPAIR_OBJECT = 5		-- 0
CharacterConstants.MORALE_BUILD_BASE = 5		-- 0
CharacterConstants.MORALE_DID_HOBBY = 5			-- 0
--CharacterConstants.MORALE_WOKE_UP_BED = 4
CharacterConstants.MORALE_DELIVERED_FOOD = 5	-- 0
CharacterConstants.MORALE_SERVED_MEAL = 5		-- 1
CharacterConstants.MORALE_DRANK_BASE = 5		-- 3
CharacterConstants.MORALE_DRANK_MAX = 6			-- 6
CharacterConstants.MORALE_ATE_MEAL_BASE = 6		-- 1
--CharacterConstants.MORALE_ATE_MEAL_MAX = 10
-- when you chat with someone nice and you're depressed, they make you happier
CharacterConstants.MORALE_HAPPY_CHAT_BASE = 5	-- 1
--CharacterConstants.MORALE_HAPPY_CHAT_MAX = 10

-- bad things
--CharacterConstants.MORALE_BAD_CHAT = 0
--CharacterConstants.MORALE_SLEPT_ON_FLOOR = -1
-- familiarity and affinity determine how bummed you feel when someone dies
CharacterConstants.MORALE_CITIZEN_DIES_MIN = -1	-- 4
CharacterConstants.MORALE_CITIZEN_DIES_MAX = -2	-- 60
-- morale loss for death plateaus beyond these familiarity + affinity levels
--CharacterConstants.MORALE_MAX_FAMILIARITY_DEATH = 100
--CharacterConstants.MORALE_MAX_AFFINITY_DEATH = 10

-- Character will rampage at 100 anger. 
-- With terrible morale, these numbers can be as much as doubled; with good morale multiplied by .4.
-- Also, everyone but the worst-tempered citizen will ignore some of these (random role vs. temper).
-- Furthermore, anger reduces every morale tick.
--CharacterConstants.ANGER_BAD_CONVO_WITH_NORMAL = 1
CharacterConstants.ANGER_BAD_CONVO_WITH_JERK = 1		-- 5
CharacterConstants.ANGER_NEARBY_BRAWL = 1				-- 15
CharacterConstants.ANGER_NEARBY_RAMPAGE = 1				-- 25
-- following 2 are unused; anger is % of max based on temper
CharacterConstants.ANGER_EMBRIGGENED_UNJUST = 1			-- 60
CharacterConstants.ANGER_EMBRIGGENED_JUST = 1			-- 15
CharacterConstants.ANGER_JOB_FAIL_TINY = 1				-- 5
CharacterConstants.ANGER_JOB_FAIL_MINOR = 1				-- 15
CharacterConstants.ANGER_JOB_FAIL_MAJOR = 1				-- 25
CharacterConstants.ANGER_BAD_FOOD = 1					-- 10
CharacterConstants.REPLICATOR_FOOD = 0					-- 3
--CharacterConstants.ANGER_MAX = 100
--CharacterConstants.ANGER_REDUCTION_PER_MORALE_TICK = 1
CharacterConstants.ANGER_REDUCTION_PER_MORALE_TICK_BRIG = 1	-- 2

-- job-related
--CharacterConstants.MAX_COMPETENCY = 10
CharacterConstants.MAX_STARTING_COMPETENCY = 9	-- 2
-- starting "skill points": total competency to dole out randomly to new citizens
CharacterConstants.STARTING_SKILL_POINTS = 10	-- 8
-- chances to fail at 0% and 100% competency
--CharacterConstants.MAX_CHANCE_TO_FAIL = 0.1
--CharacterConstants.MIN_CHANCE_TO_FAIL = 0
--CharacterConstants.NO_FAIL_COMPETENCY_THRESHOLD = 0.9
--CharacterConstants.FAILURE_XP_PENALTY = 0.5
CharacterConstants.EXPERIENCE_PER_LEVEL= 100	-- 200
--CharacterConstants.JOB_EXPERIENCE_RATE = 25.0 / 60.0


-------------------------------------------------------------------------------
-- GameEvent changes
-------------------------------------------------------------------------------

--Variable to hold reference to event definitions 
local rEvent = nil

--Minimized chance of new citizen having a disease (chance out of 100)
rEvent = require('GameEvents.Event')
rEvent.nChanceOfMalady = 1	-- 15


--Delay Breechers till 100 population
--Get reference to loaded game event definition
rEvent = require('GameEvents.BreachingEvent')
--Replace event's default function definition with custom one using "inline" method
rEvent.allowEvent = function (nPopulation, nElapsedTime) return nPopulation > 100 end	--pop over 6 or 10 minutes has passed
--Minimize event occurance (since all returns where changed to 1, just set return to 1 and remove other code)
rEvent.getWeight = function(nPop, nElapsed, bForecast) return 1.0 end	-- 10.0 if forcasted; 10.0 if exterior room exists otherwise 16.0


--Delay Compound Events till 100 population (pre/post and actual Mega Fleet events)
rEvent = require('GameEvents.CompoundEvent')
rEvent.allowEvent = function (nPopulation, nElapsedTime) return nPopulation > 100 end	--pop over 15 or 20 minutes has passed
--Minimize event occurance
rEvent.getWeight = function(nPop, nElapsed, bForecast) return 1.0 end	--60 if mega event has not occurred and time to, 15 otherwise


--Minimize Hostile Docking Events
rEvent = require('GameEvents.HostileDockingEvent')
rEvent.getWeight = function(nPop, nElapsed, bForecast) return 1.0 end	-- 5.0
--Alternavely, add the "allowEvent" method to the event class (since it did not exist already) if want to disable or adjust otherwise
--rEvent.allowEvent = function (nPopulation, nElapsedTime) if bDebugFlag then print("<<<<HostileDockingEvent disabled>>>>") end return false end


--Disable Hostile Immigration Events
rEvent = require('GameEvents.HostileImmigrationEvent')
--NOTE: probably best to just return false otherwise might have rare occurance of 0 pop and this event happening (unless that was intended)
rEvent.allowEvent = function (nPopulation, nElapsedTime) return nPopulation < 1 end		--pop over 6 or 12 minutes have passed
--Minimize event occurance (just to be sure?)
rEvent.getWeight = function(nPop, nElapsed, bForecast) return 1.0 end	-- 15.0


--Delay Meteor strikes till 100 population
rEvent = require('GameEvents.MeteorEvent')
rEvent.allowEvent = function (nPopulation, nElapsedTime) return nPopulation > 100 end	--pop over 4 or 10 minutes has passed
--Minimize event occurance
rEvent.getWeight = function(nPop, nElapsed, bForecast) return 1.0 end	-- 10.0



print(">>>>Sandbox Mode Mod by Cridge, v1 Loaded<<<<")
