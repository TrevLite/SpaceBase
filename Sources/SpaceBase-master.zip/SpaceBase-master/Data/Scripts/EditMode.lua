
local EditMode = {
}

function EditMode.init()
end

return EditMode
