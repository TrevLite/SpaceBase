-- $Id$
-- Copyright 2013 Double Fine Productions
-- All rights reserved.  Proprietary and Confidential.
--
-- Game-specific global config.
-- Users modify this file to override default settings from GameConfig.lua

-- Uncomment and change LOG_STATUS to change the spamminess from default
-- MOAILogMgr.setLogLevel ( MOAILogMgr.LOG_STATUS )

-- Make the texture spam less verbose (or disable entirely)
-- MOAILogMgr.registerLogMessage ( MOAILogMgr.MOAITexture_MemoryUse_SDFS, '%s%6lu %3.0fM %s' )
