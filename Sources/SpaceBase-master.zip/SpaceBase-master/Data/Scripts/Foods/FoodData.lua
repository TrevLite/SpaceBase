local FoodData = {}

FoodData.tFoods =
{
    Corn = { friendlyNameLinecode='FOODSX001TEXT', },
    Pod = { friendlyNameLinecode='FOODSX002TEXT', },
    Glowfruit = { friendlyNameLinecode='FOODSX003TEXT', },
    CandyCane = { friendlyNameLinecode='FOODSX004TEXT', },
}

return FoodData