local Class=require('Class')
local EnvObject=require('EnvObjects.EnvObject')

local WeightBench = Class.create(EnvObject, MOAIProp.new)

return WeightBench
