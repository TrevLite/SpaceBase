local DFUtil = require('DFCommon.Util')
local Character = require('CharacterConstants')
local tAnimations = {}

return tAnimations

