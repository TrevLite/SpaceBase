local Gui = require('UI.Gui')

local nButtonWidth, nButtonHeight  = 418, 90
local buttonX = 200

return
{
    posInfo =
    {
        alignX = 'left',
        alignY = 'top',
        offsetX = 0,
        offsetY = 20,
    },
    tExtraInfo =
    {
    },
    tElements =
    {
    },
}