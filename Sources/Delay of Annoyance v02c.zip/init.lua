--
-- Team DoubleSpank's SBDF-9v1.06 MOD / Delay of Annoyance v.02c
-- by Caesar and TheLoneWolf (Steam ID)
-- 
-- Mod loader based version so standard game files are not overwritten
-- Conversion by WrathOf/Squirrely Wrath (DF Forum/Steam ID)
--

local modname = "Delay of Annoyance Mod"
local modversion = "v.02c"

--Add mod name to app version so shows on title and menu screens
local str = MOAIEnvironment.appVersion
local i = string.find(str, '\n')
--add newline if not found
if not i then str = str..'\n' end
--add spacer if previous mod name exists (based on chars existing after newline)
if i and string.len(string.sub(str, i+1)) > 0 then str = str..' - ' end
--add this mod's name
str = str..modname..' '..modversion
MOAIEnvironment.appVersion = str


local bDebugFlag = false

--Recreate references from original code for use in replacement functions
local DFGraphics = require('DFCommon.Graphics')
local DFUtil = require('DFCommon.Util')
local DialogSets = require('DialogSets')
local MiscUtil = require("MiscUtil")
local Renderer = require('Renderer')

local EnvObject = require('EnvObjects.EnvObject')
local GameRules = require('GameRules')



-------------------------------------------------------------------------------
-- GameRules.lua changes
-------------------------------------------------------------------------------

--Change variables to adjust settings as desired
GameRules.STARTING_MATTER = 5000		--2000
-- matter yield based on miner skill
GameRules.MAT_MINE_ROCK_MIN = 50		--30
GameRules.MAT_MINE_ROCK_MAX = 70		--50
GameRules.MAT_MINE_ROCK_MIN_LVL2 = 60	--40
GameRules.MAT_MINE_ROCK_MAX_LVL2 = 80	--60
-- % of an object's original cost you get from vaporizing it
GameRules.MAT_VAPE_OBJECT_PCT = 0.95	--0.75
-- matter gained from remains
GameRules.MAT_CORPSE_MIN = 250			--130
GameRules.MAT_CORPSE_MAX = 350			--170


-- life support system
-- (# of recyclers needed to support 1 citizen)
--NOTE: Not sure this does anything more than adjust the UI display vs the 
--      actual 02 simulation in space.exe (MOAI grid based?)
GameRules.RECYCLERS_PER_CITIZEN = 5		--3



-------------------------------------------------------------------------------
-- EnvObject.lua changes
-------------------------------------------------------------------------------

--Increase tech maintainance ability (percentage)
EnvObject.MIN_PCT_HEALED_PER_MAINTAIN = 25	--2
EnvObject.MAX_PCT_HEALED_PER_MAINTAIN = 50	--25



-------------------------------------------------------------------------------
-- GameEvent changes
-------------------------------------------------------------------------------

--Variable to hold reference to event definitions 
local rEvent = nil

--Delay Breechers till 35 population
--Get reference to loaded game event definition
rEvent = require('GameEvents.BreachingEvent')
--Replace event's default function definition with custom one using "inline" method
rEvent.allowEvent = function (nPopulation, nElapsedTime) return nPopulation > 35 end


--Delay Hostile Immigration till 100 population
rEvent = require('GameEvents.HostileImmigrationEvent')
rEvent.allowEvent = function (nPopulation, nElapsedTime) return nPopulation > 100 end


--Delay Mega Fleet till 100 population
rEvent = require('GameEvents.CompoundEvent')
rEvent.allowEvent = function (nPopulation, nElapsedTime) return nPopulation > 100 end

--Delay Meteors till 200 population
rEvent = require('GameEvents.MeteorEvent')
rEvent.allowEvent = function (nPopulation, nElapsedTime) return nPopulation > 200 end

--Remove Hostile Derelicts
rEvent = require('GameEvents.HostileDerelictEvent')
--Disable event by setting weight to 0
rEvent.getWeight = function(nPop, nElapsed, bForecast) return 0 end
--Alternavely, add the "allowEvent" method to the event class since it did not exist already
rEvent.allowEvent = function (nPopulation, nElapsedTime) if bDebugFlag then print("<<<<HostileDerelictEvent disabled>>>>") end return false end


--Hostile Docking refusal adjusted
rEvent = require('GameEvents.HostileDockingEvent')
--Disable event by setting weight to 0 (since all returns where changed to 0, just set return to 0 and remove other code)
rEvent.getWeight = function(nPop,nElapsed,bForecast) return 0 end --instead of 5.0
--Alternavely, add the "allowEvent" method to the event class since it did not exist already
rEvent.allowEvent = function (nPopulation, nElapsedTime) if bDebugFlag then print("<<<<HostileDockingEvent disabled>>>>") end return false end
rEvent._ignoreRefusal = function(tPersistentEventState) return math.random() > 0.99 end --instead of 0.33
rEvent._getDialogSet = function()
  local sKey = 'ambiguous'
  if math.random() > .9 then --instead of .3
    sKey = 'hostile'
  end
  return DFUtil.arrayRandom(DialogSets['dockingEvents'][sKey])
end



-------------------------------------------------------------------------------
-- PlantData.lua changes
-------------------------------------------------------------------------------

--Swap hydro plants to candy cane plants to force appearance always or replace
--code to allow them to appear in November and December

--[[
--Since CandyCane already defined, just set Pod plant to reference it
--Note: CandyCane plants will appear automatically in December (per HydroPlant init)
local PlantData = require('Foods.PlantData')
PlantData.tPlants.Pod = PlantData.tPlants.CandyCane
--]]--

--[[
--Alternatively, define to information as copy of CandyCane info
local PlantData = require('Foods.PlantData')
PlantData.tPlants.Pod =
{
  ageInfo=
  {
    {nAbove=0.00, spriteName='plant_xmas_a'},
    {nAbove=0.60, spriteName='plant_xmas_b'},
    {nAbove=0.80, spriteName='plant_xmas_c', bCanBeEaten=true},
    {nAbove=0.98, spriteName='plant_xmas_c', bCanBeHarvested=true, bCanBeEaten=true},
  },
  nLifeTime = 500,
  sPlantLC = 'PROPSX051TEXT',
  tHarvestableFoods =
  { 
    CandyCane = {
      tNumHarvestedRange={1,5},
    },
  },
}
--]]--

--
--Or replace HydroPlant init function with custom one that enables CandyCane plant to appear anytime or Nov & Dec months
--This method does involve duplicating a lot of code that will need to be checked and updated after each official game patch though
--Note: this is a special case where the original function is a "method" so the new function needs to add the "self" parameter to work correctly
local PlantData = require('Foods.PlantData')
local HydroPlant = require('EnvObjects.HydroPlant')
HydroPlant.init = function(self,sName, wx, wy, bFlipX, bFlipY, bForce, tSaveData, nTeam)

    local tData = EnvObject.getObjectData(sName)
    
    self.nPlantAge = 0
    self.nPlantHealth = HydroPlant.DEFAULT_HEALTH
    self.bSeeded = false
    if tSaveData then
        if tSaveData.nPlantAge then
            self.nPlantAge = tSaveData.nPlantAge
        end
        if tSaveData.nPlantHealth then
            self.nPlantHealth = tSaveData.nPlantHealth
        end
        self.bSeeded = tSaveData.bSeeded or (self.nPlantAge > 0)
        if tSaveData.sPlantType then 
            self.sPlantType = tSaveData.sPlantType 
        end
        self.nEatMeCooldown = tSaveData.nEatMeCooldown
    end
    -- for now we just get plants at random
    if not self.sPlantType or not PlantData.tPlants[self.sPlantType] then
		self.sPlantType = MiscUtil.randomKey(PlantData.tPlants)
--MOD/
		-- HOLIDAY FUN: only plant candy cane trees in november and december!
		local tDate = os.date('*t', os.time())
		if tDate.month < 11 then
			while self.sPlantType == 'CandyCane' do
				self.sPlantType = MiscUtil.randomKey(PlantData.tPlants)
			end
		end
--/MOD
    end
    self.rPlantData = PlantData.tPlants[self.sPlantType]
	-- remember plant name for tooltip etc
	self.sPlantName = g_LM.line(PlantData.tPlants[self.sPlantType].sPlantLC)

    self.healthDecayPerSecond = HydroPlant.AGE_TO_DECAY_RATIO * 100 / self.rPlantData.nLifeTime
    
    local tActivityData=
    {
        rTargetObject=self,
        bNoPathToNearestDiagonal=true,
        utilityGateFn=function(rChar,rAO)
            return self:_harvestAndDeliverGate(rChar,rAO)
        end,
    }    
    local tMaintainActivityData=
    {
        rTargetObject=self,
        bNoPathToNearestDiagonal=true,
        utilityGateFn=function(rChar,rAO)
            return self:_maintainPlantGate(rChar,rAO)
        end,
        utilityOverrideFn=function(rChar,rAO,nOriginalUtility) 
            return self:getMaintainPlantUtility(rChar,nOriginalUtility) 
        end,
    }
    local tEatPlantData=
    {
        rTargetObject=self,
        bNoPathToNearestDiagonal=true,
        utilityGateFn=function(rChar,rAO)
            return self:_eatPlantGate(rChar,rAO)
        end,
    }

    self.rHarvestOption = g_ActivityOption.new('HarvestAndDeliverFood',tActivityData)
    self.rMaintainPlantOption = g_ActivityOption.new('MaintainPlants', tMaintainActivityData)
    self.rEatPlantOption = g_ActivityOption.new('EatPlant', tEatPlantData)

    EnvObject.init(self,sName, wx, wy, bFlipX, bFlipY, bForce, tSaveData, nTeam)
    -- create the plant prop
    self.rPlantSpriteSheet = DFGraphics.loadSpriteSheet(EnvObject.spriteSheetPath, false, false, false)
    if self.rPlantSpriteSheet then
        self.rPlantProp = MOAIProp.new()
        self.rPlantProp:setDeck(self.rPlantSpriteSheet)
		-- ref so GuiManager._getTargetAt can recognize it
		self.rPlantProp.rEnvObjParent = self
        MiscUtil.setTransformVisParent(self.rPlantProp, self)
        self.rPlantProp:setLoc(-64, -26)
        Renderer.getRenderLayer(self.layer):insertProp(self.rPlantProp)
    end
    self:_adjustVisuals()

end
--]]--  


print(">>>>"..modname..", "..modversion.." Loaded<<<<")

